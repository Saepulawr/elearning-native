# ************************************************************
# Sequel Ace SQL dump
# Version 3030
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.4.14-MariaDB)
# Database: dev_learning
# Generation Time: 2021-06-07 16:13:51 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table analisis
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analisis`;

CREATE TABLE `analisis` (
  `id_analisis` int(100) NOT NULL AUTO_INCREMENT,
  `id_ujian` int(100) NOT NULL,
  `id_soal` int(100) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `jawaban` varchar(100) NOT NULL,
  PRIMARY KEY (`id_analisis`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

LOCK TABLES `analisis` WRITE;
/*!40000 ALTER TABLE `analisis` DISABLE KEYS */;

INSERT INTO `analisis` (`id_analisis`, `id_ujian`, `id_soal`, `id_siswa`, `jawaban`)
VALUES
	(1,12,107,21,'1'),
	(2,12,111,21,'2'),
	(3,12,112,21,'2'),
	(4,12,113,21,'2'),
	(5,12,114,21,'2'),
	(6,13,115,22,'2'),
	(7,13,116,22,'2'),
	(8,13,117,22,'2'),
	(9,13,118,22,'0'),
	(10,13,119,22,'2'),
	(11,13,115,21,'2'),
	(12,13,116,21,'3'),
	(13,13,117,21,'2'),
	(14,13,118,21,'2'),
	(15,13,119,21,'2'),
	(16,14,120,1,'1'),
	(17,14,121,1,'2'),
	(18,14,122,1,'2'),
	(19,14,123,1,'2'),
	(20,14,124,1,'3'),
	(21,14,120,2,'1'),
	(22,14,121,2,'2'),
	(23,14,122,2,'2'),
	(24,14,123,2,'2'),
	(25,14,124,2,'3');

/*!40000 ALTER TABLE `analisis` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table kelas_tugas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `kelas_tugas`;

CREATE TABLE `kelas_tugas` (
  `id_klstugas` int(11) NOT NULL AUTO_INCREMENT,
  `id_tugas` int(11) NOT NULL,
  `id_kelas` int(5) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_klstugas`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `kelas_tugas` WRITE;
/*!40000 ALTER TABLE `kelas_tugas` DISABLE KEYS */;

INSERT INTO `kelas_tugas` (`id_klstugas`, `id_tugas`, `id_kelas`, `id_jurusan`, `aktif`)
VALUES
	(1,1,13,6,'Y');

/*!40000 ALTER TABLE `kelas_tugas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table kelas_ujian
# ------------------------------------------------------------

DROP TABLE IF EXISTS `kelas_ujian`;

CREATE TABLE `kelas_ujian` (
  `id_klsujian` int(11) NOT NULL AUTO_INCREMENT,
  `id_ujian` int(5) NOT NULL,
  `id_kelas` int(5) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_klsujian`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `kelas_ujian` WRITE;
/*!40000 ALTER TABLE `kelas_ujian` DISABLE KEYS */;

INSERT INTO `kelas_ujian` (`id_klsujian`, `id_ujian`, `id_kelas`, `id_jurusan`, `aktif`)
VALUES
	(1,14,13,6,'Y');

/*!40000 ALTER TABLE `kelas_ujian` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table kelas_ujianessay
# ------------------------------------------------------------

DROP TABLE IF EXISTS `kelas_ujianessay`;

CREATE TABLE `kelas_ujianessay` (
  `id_klsessay` int(11) NOT NULL AUTO_INCREMENT,
  `id_ujianessay` int(11) NOT NULL,
  `id_kelas` int(5) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_klsessay`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

LOCK TABLES `kelas_ujianessay` WRITE;
/*!40000 ALTER TABLE `kelas_ujianessay` DISABLE KEYS */;

INSERT INTO `kelas_ujianessay` (`id_klsessay`, `id_ujianessay`, `id_kelas`, `id_jurusan`, `aktif`)
VALUES
	(3,14,13,6,'Y');

/*!40000 ALTER TABLE `kelas_ujianessay` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table nilai
# ------------------------------------------------------------

DROP TABLE IF EXISTS `nilai`;

CREATE TABLE `nilai` (
  `id_nilai` int(10) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) NOT NULL,
  `id_ujian` varchar(100) NOT NULL,
  `acak_soal` text NOT NULL,
  `jawaban` text NOT NULL,
  `sisa_waktu` time NOT NULL,
  `waktu_selesai` time NOT NULL,
  `jml_benar` int(5) NOT NULL,
  `jml_kosong` int(5) NOT NULL,
  `jml_salah` int(5) NOT NULL,
  `nilai` varchar(5) NOT NULL,
  PRIMARY KEY (`id_nilai`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `nilai` WRITE;
/*!40000 ALTER TABLE `nilai` DISABLE KEYS */;

INSERT INTO `nilai` (`id_nilai`, `id_siswa`, `id_ujian`, `acak_soal`, `jawaban`, `sisa_waktu`, `waktu_selesai`, `jml_benar`, `jml_kosong`, `jml_salah`, `nilai`)
VALUES
	(1,1,'14','120,123,124,121,122','1,2,3,2,2','00:05:00','20:05:05',5,0,0,'100'),
	(2,2,'14','122,123,124,120,121','2,2,3,1,2','00:05:00','08:47:43',5,0,0,'100');

/*!40000 ALTER TABLE `nilai` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pesan
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pesan`;

CREATE TABLE `pesan` (
  `id_pesan` int(10) NOT NULL AUTO_INCREMENT,
  `id_pengirim` varchar(30) NOT NULL,
  `id_penerima` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `isi_pesan` longtext NOT NULL,
  `sudah_dibaca` enum('belum','sudah') NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `pesan` WRITE;
/*!40000 ALTER TABLE `pesan` DISABLE KEYS */;

INSERT INTO `pesan` (`id_pesan`, `id_pengirim`, `id_penerima`, `tanggal`, `isi_pesan`, `sudah_dibaca`, `id_kelas`, `id_jurusan`)
VALUES
	(1,'119200001','199509090001','2020-04-21','Pak saya sudah kerjakan tugas bapak.','sudah',13,6),
	(2,'199509090001','119200001','2020-04-21','Re: <p>Ok siap</p>\r\n','belum',13,6);

/*!40000 ALTER TABLE `pesan` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table soal
# ------------------------------------------------------------

DROP TABLE IF EXISTS `soal`;

CREATE TABLE `soal` (
  `id_soal` int(5) NOT NULL AUTO_INCREMENT,
  `id_ujian` int(5) NOT NULL,
  `soal` text NOT NULL,
  `pilihan_1` text NOT NULL,
  `pilihan_2` text NOT NULL,
  `pilihan_3` text NOT NULL,
  `pilihan_4` text NOT NULL,
  `pilihan_5` text NOT NULL,
  `kunci` int(2) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_soal`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=latin1;

LOCK TABLES `soal` WRITE;
/*!40000 ALTER TABLE `soal` DISABLE KEYS */;

INSERT INTO `soal` (`id_soal`, `id_ujian`, `soal`, `pilihan_1`, `pilihan_2`, `pilihan_3`, `pilihan_4`, `pilihan_5`, `kunci`, `status`)
VALUES
	(106,11,'1+18','18','19','20','21','22',2,'Y'),
	(105,11,'1+17','17','18','19','20','21',1,'Y'),
	(104,11,'1+16','16','17','18','19','20',1,'Y'),
	(103,11,'1+15','15','16','17','18','19',1,'Y'),
	(102,11,'1+14','14','15','16','17','18',1,'Y'),
	(101,11,'1+13','13','14','15','16','17',2,'Y'),
	(100,11,'1+12','12','13','14','15','16',3,'Y'),
	(99,11,'1+11','11','12','13','14','15',4,'Y'),
	(98,11,'1+10','10','11','12','13','14',5,'Y'),
	(97,11,'1+9','9','10','11','12','13',4,'Y'),
	(96,11,'1+8','8','9','10','11','12',3,'Y'),
	(95,11,'1+7','7','8','9','10','11',2,'Y'),
	(94,11,'1+6','6','7','8','9','10',3,'Y'),
	(93,11,'1+5','5','6','7','8','9',2,'Y'),
	(92,11,'1+4','4','5','6','7','8',2,'Y'),
	(91,11,'1+3','3','4','5','6','7',2,'Y'),
	(90,11,'1+2','2','3','4','5','6',3,'Y'),
	(89,11,'1+1','1','2','3','4','5',2,'Y'),
	(107,12,'<p>Pertanyaan 1?</p>\r\n','A','B','C','D','E',1,'Y'),
	(113,12,'1+3','3','4','5','6','7',2,'Y'),
	(112,12,'1+2','2','3','4','5','6',3,'Y'),
	(111,12,'1+1','1','2','3','4','5',2,'Y'),
	(114,12,'1+4','4','5','6','7','8',2,'Y'),
	(115,13,'1+1','1','2','3','4','5',2,'Y'),
	(116,13,'1+2','2','3','4','5','6',3,'Y'),
	(117,13,'1+3','3','4','5','6','7',2,'Y'),
	(118,13,'1+4','4','5','6','7','8',2,'Y'),
	(119,13,'1+5','5','6','7','9','8',2,'Y'),
	(120,14,'<p>Soal nomor satu?</p>\r\n','A benar','B','C','D','E',1,'Y'),
	(121,14,'1+1','1','2','3','4','5',2,'Y'),
	(122,14,'1+2','2','3','4','5','6',2,'Y'),
	(123,14,'1+3','3','4','5','6','7',2,'Y'),
	(124,14,'1+4','4','6','5','7','8',3,'Y');

/*!40000 ALTER TABLE `soal` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_admin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_admin`;

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `aktif` varchar(5) NOT NULL,
  `foto` varchar(225) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_admin` WRITE;
/*!40000 ALTER TABLE `tb_admin` DISABLE KEYS */;

INSERT INTO `tb_admin` (`id_admin`, `nama_lengkap`, `username`, `password`, `aktif`, `foto`)
VALUES
	(1,'Admin','admin','d033e22ae348aeb5660fc2140aec35850c4da997','Y','support.png');

/*!40000 ALTER TABLE `tb_admin` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_guru
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_guru`;

CREATE TABLE `tb_guru` (
  `id_guru` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) NOT NULL,
  `nama_guru` varchar(120) NOT NULL,
  `email` varchar(65) NOT NULL,
  `password` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `status` varchar(5) NOT NULL,
  `date_created` date NOT NULL,
  `confirm` enum('Yes','No') NOT NULL,
  PRIMARY KEY (`id_guru`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_guru` WRITE;
/*!40000 ALTER TABLE `tb_guru` DISABLE KEYS */;

INSERT INTO `tb_guru` (`id_guru`, `nik`, `nama_guru`, `email`, `password`, `foto`, `status`, `date_created`, `confirm`)
VALUES
	(7,'199509090001','Sanusi Hamzah, S.Kom.','sanusi.hamzah@gmail.com','a5c6ed7bfc61fe75b987ef19d894b0d7324a58ee','order-tanto.png','Y','2020-04-21','Yes');

/*!40000 ALTER TABLE `tb_guru` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_jenisperangkat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_jenisperangkat`;

CREATE TABLE `tb_jenisperangkat` (
  `id_jenisperangkat` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_perangkat` varchar(40) NOT NULL,
  PRIMARY KEY (`id_jenisperangkat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_jenisperangkat` WRITE;
/*!40000 ALTER TABLE `tb_jenisperangkat` DISABLE KEYS */;

INSERT INTO `tb_jenisperangkat` (`id_jenisperangkat`, `jenis_perangkat`)
VALUES
	(1,'RPP'),
	(2,'SILABUS'),
	(3,'MODUL');

/*!40000 ALTER TABLE `tb_jenisperangkat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_jenistugas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_jenistugas`;

CREATE TABLE `tb_jenistugas` (
  `id_jenistugas` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_tugas` varchar(60) NOT NULL,
  PRIMARY KEY (`id_jenistugas`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_jenistugas` WRITE;
/*!40000 ALTER TABLE `tb_jenistugas` DISABLE KEYS */;

INSERT INTO `tb_jenistugas` (`id_jenistugas`, `jenis_tugas`)
VALUES
	(1,'INDIVIDU'),
	(2,'KELOMPOK');

/*!40000 ALTER TABLE `tb_jenistugas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_jenisujian
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_jenisujian`;

CREATE TABLE `tb_jenisujian` (
  `id_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_ujian` varchar(60) NOT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_jenisujian` WRITE;
/*!40000 ALTER TABLE `tb_jenisujian` DISABLE KEYS */;

INSERT INTO `tb_jenisujian` (`id_jenis`, `jenis_ujian`)
VALUES
	(1,'PAT'),
	(2,'Harian');

/*!40000 ALTER TABLE `tb_jenisujian` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_master_jurusan
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_master_jurusan`;

CREATE TABLE `tb_master_jurusan` (
  `id_jurusan` int(11) NOT NULL AUTO_INCREMENT,
  `jurusan` varchar(45) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_master_jurusan` WRITE;
/*!40000 ALTER TABLE `tb_master_jurusan` DISABLE KEYS */;

INSERT INTO `tb_master_jurusan` (`id_jurusan`, `jurusan`)
VALUES
	(6,'Teknik Komputer dan Rekayasa');

/*!40000 ALTER TABLE `tb_master_jurusan` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_master_kelas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_master_kelas`;

CREATE TABLE `tb_master_kelas` (
  `id_kelas` int(11) NOT NULL AUTO_INCREMENT,
  `kelas` varchar(45) NOT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_master_kelas` WRITE;
/*!40000 ALTER TABLE `tb_master_kelas` DISABLE KEYS */;

INSERT INTO `tb_master_kelas` (`id_kelas`, `kelas`)
VALUES
	(13,'X');

/*!40000 ALTER TABLE `tb_master_kelas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_master_mapel
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_master_mapel`;

CREATE TABLE `tb_master_mapel` (
  `id_mapel` int(11) NOT NULL AUTO_INCREMENT,
  `mapel` varchar(60) NOT NULL,
  PRIMARY KEY (`id_mapel`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_master_mapel` WRITE;
/*!40000 ALTER TABLE `tb_master_mapel` DISABLE KEYS */;

INSERT INTO `tb_master_mapel` (`id_mapel`, `mapel`)
VALUES
	(11,'Pemrograman Dasar');

/*!40000 ALTER TABLE `tb_master_mapel` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_master_semester
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_master_semester`;

CREATE TABLE `tb_master_semester` (
  `id_semester` int(11) NOT NULL AUTO_INCREMENT,
  `semester` varchar(45) NOT NULL,
  PRIMARY KEY (`id_semester`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_master_semester` WRITE;
/*!40000 ALTER TABLE `tb_master_semester` DISABLE KEYS */;

INSERT INTO `tb_master_semester` (`id_semester`, `semester`)
VALUES
	(1,'SEMESTER 1'),
	(2,'SEMESTER 2');

/*!40000 ALTER TABLE `tb_master_semester` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_materi
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_materi`;

CREATE TABLE `tb_materi` (
  `id_materi` int(11) NOT NULL AUTO_INCREMENT,
  `judul_materi` varchar(120) NOT NULL,
  `materi` text NOT NULL,
  `nama_file` varchar(120) NOT NULL,
  `tipe_file` varchar(20) NOT NULL,
  `ukuran_file` varchar(30) NOT NULL,
  `file` varchar(255) NOT NULL,
  `tgl_entry` date NOT NULL,
  `id_roleguru` int(11) NOT NULL,
  `public` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id_materi`),
  KEY `id_roleguru` (`id_roleguru`),
  CONSTRAINT `tb_materi_ibfk_1` FOREIGN KEY (`id_roleguru`) REFERENCES `tb_roleguru` (`id_roleguru`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_materi` WRITE;
/*!40000 ALTER TABLE `tb_materi` DISABLE KEYS */;

INSERT INTO `tb_materi` (`id_materi`, `judul_materi`, `materi`, `nama_file`, `tipe_file`, `ukuran_file`, `file`, `tgl_entry`, `id_roleguru`, `public`)
VALUES
	(1,'Membuat Kalkulator sederhan dengan VB','<p>Membuat Kalkulator sederhan dengan VB</p>\r\n','1587472773','text','0','--','2020-04-21',1,'Y'),
	(2,'Membuat Kalkulator sederhan dengan PHP','','1587472830','doc','1457','../vendor/file/PERANGKAT_1587472830.doc','2020-04-21',1,'Y');

/*!40000 ALTER TABLE `tb_materi` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_perangkat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_perangkat`;

CREATE TABLE `tb_perangkat` (
  `id_perangkat` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `nama_file` varchar(120) NOT NULL,
  `tipe_file` varchar(20) NOT NULL,
  `ukuran_file` varchar(30) NOT NULL,
  `file` varchar(255) NOT NULL,
  `isi_perangkat` text NOT NULL,
  `id_jenisperangkat` int(11) NOT NULL,
  `tgl_entry` date NOT NULL,
  `publish` int(11) NOT NULL,
  `id_roleguru` int(11) NOT NULL,
  PRIMARY KEY (`id_perangkat`),
  KEY `id_roleguru` (`id_roleguru`),
  CONSTRAINT `tb_perangkat_ibfk_1` FOREIGN KEY (`id_roleguru`) REFERENCES `tb_roleguru` (`id_roleguru`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_perangkat` WRITE;
/*!40000 ALTER TABLE `tb_perangkat` DISABLE KEYS */;

INSERT INTO `tb_perangkat` (`id_perangkat`, `judul`, `nama_file`, `tipe_file`, `ukuran_file`, `file`, `isi_perangkat`, `id_jenisperangkat`, `tgl_entry`, `publish`, `id_roleguru`)
VALUES
	(1,'RPP Progdas','1587472377','text','File','--','<p><strong>RPP Progdas</strong></p>\r\n',1,'2020-04-21',1,1),
	(2,'RPP Progdas Oke','1587472687','doc','1446','../vendor/file/PERANGKAT_1587472687.doc','',1,'2020-04-21',1,1);

/*!40000 ALTER TABLE `tb_perangkat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_roleguru
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_roleguru`;

CREATE TABLE `tb_roleguru` (
  `id_roleguru` int(11) NOT NULL AUTO_INCREMENT,
  `id_guru` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  PRIMARY KEY (`id_roleguru`),
  KEY `id_guru` (`id_guru`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_semester` (`id_semester`),
  KEY `id_jurusan` (`id_jurusan`),
  CONSTRAINT `tb_roleguru_ibfk_1` FOREIGN KEY (`id_guru`) REFERENCES `tb_guru` (`id_guru`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_roleguru_ibfk_2` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_master_jurusan` (`id_jurusan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_roleguru_ibfk_3` FOREIGN KEY (`id_kelas`) REFERENCES `tb_master_kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_roleguru_ibfk_4` FOREIGN KEY (`id_mapel`) REFERENCES `tb_master_mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_roleguru_ibfk_5` FOREIGN KEY (`id_semester`) REFERENCES `tb_master_semester` (`id_semester`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_roleguru` WRITE;
/*!40000 ALTER TABLE `tb_roleguru` DISABLE KEYS */;

INSERT INTO `tb_roleguru` (`id_roleguru`, `id_guru`, `id_kelas`, `id_mapel`, `id_semester`, `id_jurusan`)
VALUES
	(1,7,13,11,2,6);

/*!40000 ALTER TABLE `tb_roleguru` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_sekolah
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_sekolah`;

CREATE TABLE `tb_sekolah` (
  `id_sekolah` int(11) NOT NULL AUTO_INCREMENT,
  `nama_sekolah` varchar(120) NOT NULL,
  `kepsek` varchar(120) NOT NULL,
  `textlogo` varchar(120) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  PRIMARY KEY (`id_sekolah`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_sekolah` WRITE;
/*!40000 ALTER TABLE `tb_sekolah` DISABLE KEYS */;

INSERT INTO `tb_sekolah` (`id_sekolah`, `nama_sekolah`, `kepsek`, `textlogo`, `logo`, `copyright`)
VALUES
	(1,'SMKN 1 Kota Indonesia','Dadang Sunarno, M.Pd.','E-Classroom','favicon.png',' Copyright ï¿½ 2020 <b>E-Learning</b>. All rights reserved');

/*!40000 ALTER TABLE `tb_sekolah` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_siswa
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_siswa`;

CREATE TABLE `tb_siswa` (
  `id_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `nis` varchar(15) NOT NULL,
  `nama_siswa` varchar(120) NOT NULL,
  `jk` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL,
  `aktif` varchar(30) NOT NULL,
  `tingkat` varchar(20) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `confirm` enum('Yes','No') NOT NULL,
  PRIMARY KEY (`id_siswa`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_jurusan` (`id_jurusan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

LOCK TABLES `tb_siswa` WRITE;
/*!40000 ALTER TABLE `tb_siswa` DISABLE KEYS */;

INSERT INTO `tb_siswa` (`id_siswa`, `nis`, `nama_siswa`, `jk`, `password`, `status`, `aktif`, `tingkat`, `foto`, `id_kelas`, `id_jurusan`, `confirm`)
VALUES
	(1,'119200001','Zaenudin Rahmat','L','af5e7eeac40eeeee5fc7192de5359f5029e4cc4e','Online','Y','0','default.png',13,6,'Yes'),
	(2,'119200002','Ratna Sari','P','fe7bd1a2d50a19e21954c9f93fac7466387ceba9','off','Y','0','bendera.jpg',13,6,'Yes');

/*!40000 ALTER TABLE `tb_siswa` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tb_tugas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tb_tugas`;

CREATE TABLE `tb_tugas` (
  `id_tugas` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenistugas` int(11) NOT NULL,
  `judul_tugas` varchar(100) NOT NULL,
  `isi_tugas` text NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` int(30) NOT NULL,
  `jml_anggota` int(30) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  PRIMARY KEY (`id_tugas`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `tb_tugas` WRITE;
/*!40000 ALTER TABLE `tb_tugas` DISABLE KEYS */;

INSERT INTO `tb_tugas` (`id_tugas`, `id_jenistugas`, `judul_tugas`, `isi_tugas`, `tanggal`, `waktu`, `jml_anggota`, `id_guru`, `id_mapel`, `id_semester`)
VALUES
	(1,1,'Membuat Kalkulator sederhan dengan PHP','<p>Segera kerjakan tugas makalah membuat kalkulator berbasis web PHP</p>\r\n','2021-06-06',3,0,7,11,2);

/*!40000 ALTER TABLE `tb_tugas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tugas_siswa
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tugas_siswa`;

CREATE TABLE `tugas_siswa` (
  `id_tgssiswa` int(11) NOT NULL AUTO_INCREMENT,
  `id_tugas` int(11) NOT NULL,
  `subjek` varchar(120) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `kelompok` text NOT NULL,
  `nama_file` varchar(120) NOT NULL,
  `tipe_file` varchar(30) NOT NULL,
  `ukuran_file` varchar(30) NOT NULL,
  `file` varchar(255) NOT NULL,
  `tgl_upload` date NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_tgssiswa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `tugas_siswa` WRITE;
/*!40000 ALTER TABLE `tugas_siswa` DISABLE KEYS */;

INSERT INTO `tugas_siswa` (`id_tgssiswa`, `id_tugas`, `subjek`, `id_siswa`, `kelompok`, `nama_file`, `tipe_file`, `ukuran_file`, `file`, `tgl_upload`, `ket`)
VALUES
	(1,1,'Membuat Kalkulator sederhan dengan PHP',1,'','1587473255','doc','1483','../vendor/file/tugasTUGAS-INDIVIDU_1587473255.doc','2020-04-21','Selesai');

/*!40000 ALTER TABLE `tugas_siswa` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ujian
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ujian`;

CREATE TABLE `ujian` (
  `id_ujian` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `jml_soal` int(30) NOT NULL,
  `acak` varchar(100) NOT NULL,
  `tipe` int(1) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  PRIMARY KEY (`id_ujian`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

LOCK TABLES `ujian` WRITE;
/*!40000 ALTER TABLE `ujian` DISABLE KEYS */;

INSERT INTO `ujian` (`id_ujian`, `judul`, `tanggal`, `waktu`, `jml_soal`, `acak`, `tipe`, `id_jenis`, `id_guru`, `id_mapel`, `id_semester`)
VALUES
	(14,'Kalkulator','2020-04-21','00:05:00',5,'acak',0,2,7,11,2);

/*!40000 ALTER TABLE `ujian` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ujian_essay
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ujian_essay`;

CREATE TABLE `ujian_essay` (
  `id_ujianessay` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `jml_soal` int(30) NOT NULL,
  `soal_essay` text NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  PRIMARY KEY (`id_ujianessay`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table v_siswa_tugas_selesai
# ------------------------------------------------------------

DROP VIEW IF EXISTS `v_siswa_tugas_selesai`;

CREATE TABLE `v_siswa_tugas_selesai` (
   `id_tugas` INT(11) NOT NULL DEFAULT '0',
   `id_jenistugas` INT(11) NOT NULL,
   `jenis_tugas` VARCHAR(60) NOT NULL,
   `judul_tugas` VARCHAR(100) NOT NULL,
   `isi_tugas` TEXT NOT NULL,
   `tanggal` DATE NOT NULL,
   `waktu` INT(30) NOT NULL,
   `jml_anggota` INT(30) NOT NULL,
   `id_guru` INT(11) NOT NULL,
   `nik` VARCHAR(20) NOT NULL,
   `nama_guru` VARCHAR(120) NOT NULL,
   `id_mapel` INT(11) NOT NULL,
   `mapel` VARCHAR(60) NOT NULL,
   `id_semester` INT(11) NOT NULL,
   `semester` VARCHAR(45) NOT NULL,
   `id_siswa` INT(11) NOT NULL,
   `nis` VARCHAR(15) NOT NULL,
   `nama_siswa` VARCHAR(120) NOT NULL,
   `ket` TEXT NOT NULL,
   `tgl_upload` DATE NOT NULL
) ENGINE=MyISAM;



# Dump of table v_tugas_dari_guru
# ------------------------------------------------------------

DROP VIEW IF EXISTS `v_tugas_dari_guru`;

CREATE TABLE `v_tugas_dari_guru` (
   `id_tugas` INT(11) NOT NULL DEFAULT '0',
   `id_jenistugas` INT(11) NOT NULL,
   `jenis_tugas` VARCHAR(60) NOT NULL,
   `judul_tugas` VARCHAR(100) NOT NULL,
   `isi_tugas` TEXT NOT NULL,
   `tanggal` DATE NOT NULL,
   `waktu` INT(30) NOT NULL,
   `jml_anggota` INT(30) NOT NULL,
   `id_guru` INT(11) NOT NULL,
   `nik` VARCHAR(20) NOT NULL,
   `nama_guru` VARCHAR(120) NOT NULL,
   `id_mapel` INT(11) NOT NULL,
   `mapel` VARCHAR(60) NOT NULL,
   `id_semester` INT(11) NOT NULL,
   `semester` VARCHAR(45) NOT NULL,
   `kelas` VARCHAR(45) NOT NULL
) ENGINE=MyISAM;





# Replace placeholder table for v_tugas_dari_guru with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_tugas_dari_guru`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_tugas_dari_guru`
AS SELECT
   `tt`.`id_tugas` AS `id_tugas`,
   `tt`.`id_jenistugas` AS `id_jenistugas`,
   `tj`.`jenis_tugas` AS `jenis_tugas`,
   `tt`.`judul_tugas` AS `judul_tugas`,
   `tt`.`isi_tugas` AS `isi_tugas`,
   `tt`.`tanggal` AS `tanggal`,
   `tt`.`waktu` AS `waktu`,
   `tt`.`jml_anggota` AS `jml_anggota`,
   `tt`.`id_guru` AS `id_guru`,
   `tg`.`nik` AS `nik`,
   `tg`.`nama_guru` AS `nama_guru`,
   `tt`.`id_mapel` AS `id_mapel`,
   `tmm`.`mapel` AS `mapel`,
   `tt`.`id_semester` AS `id_semester`,
   `tms`.`semester` AS `semester`,
   `tmk`.`kelas` AS `kelas`
FROM ((((((`tb_tugas` `tt` join `tb_guru` `tg`) join `tb_jenistugas` `tj`) join `tb_master_mapel` `tmm`) join `tb_master_semester` `tms`) join `kelas_tugas` `kt`) join `tb_master_kelas` `tmk`) where `tt`.`id_guru` = `tg`.`id_guru` and `tt`.`id_jenistugas` = `tj`.`id_jenistugas` and `tt`.`id_mapel` = `tmm`.`id_mapel` and `tt`.`id_semester` = `tms`.`id_semester` and `tt`.`id_tugas` = `kt`.`id_tugas` and `kt`.`id_kelas` = `tmk`.`id_kelas`;


# Replace placeholder table for v_siswa_tugas_selesai with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_siswa_tugas_selesai`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_siswa_tugas_selesai`
AS SELECT
   `vtdg`.`id_tugas` AS `id_tugas`,
   `vtdg`.`id_jenistugas` AS `id_jenistugas`,
   `vtdg`.`jenis_tugas` AS `jenis_tugas`,
   `vtdg`.`judul_tugas` AS `judul_tugas`,
   `vtdg`.`isi_tugas` AS `isi_tugas`,
   `vtdg`.`tanggal` AS `tanggal`,
   `vtdg`.`waktu` AS `waktu`,
   `vtdg`.`jml_anggota` AS `jml_anggota`,
   `vtdg`.`id_guru` AS `id_guru`,
   `vtdg`.`nik` AS `nik`,
   `vtdg`.`nama_guru` AS `nama_guru`,
   `vtdg`.`id_mapel` AS `id_mapel`,
   `vtdg`.`mapel` AS `mapel`,
   `vtdg`.`id_semester` AS `id_semester`,
   `vtdg`.`semester` AS `semester`,
   `ts`.`id_siswa` AS `id_siswa`,
   `ts2`.`nis` AS `nis`,
   `ts2`.`nama_siswa` AS `nama_siswa`,
   `ts`.`ket` AS `ket`,
   `ts`.`tgl_upload` AS `tgl_upload`
FROM ((`v_tugas_dari_guru` `vtdg` join `tugas_siswa` `ts`) join `tb_siswa` `ts2`) where `vtdg`.`id_tugas` = `ts`.`id_tugas` and `ts`.`id_siswa` = `ts2`.`id_siswa`;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
